// js/auth.js
