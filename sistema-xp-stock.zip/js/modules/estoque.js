// js/modules/estoque.js
